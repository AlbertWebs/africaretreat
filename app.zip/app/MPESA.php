<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MPESA extends Model
{
    public $table = 'mpesa_payments';
}
