<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Page_Settings extends Model
{
    public $table = 'pages_settings';
}
