<style>

<link href="//db.onlinewebfonts.com/c/b5eae9bab2129f4acd5fcd349dc804fe?family=Nirmala+UI+Semilight" rel="stylesheet" type="text/css"/>
@import url(//db.onlinewebfonts.com/c/b5eae9bab2129f4acd5fcd349dc804fe?family=Nirmala+UI+Semilight);
@font-face {font-family: "Nirmala UI Semilight"; src: url("//db.onlinewebfonts.com/t/b5eae9bab2129f4acd5fcd349dc804fe.eot"); src: url("//db.onlinewebfonts.com/t/b5eae9bab2129f4acd5fcd349dc804fe.eot?#iefix") format("embedded-opentype"), url("//db.onlinewebfonts.com/t/b5eae9bab2129f4acd5fcd349dc804fe.woff2") format("woff2"), url("//db.onlinewebfonts.com/t/b5eae9bab2129f4acd5fcd349dc804fe.woff") format("woff"), url("//db.onlinewebfonts.com/t/b5eae9bab2129f4acd5fcd349dc804fe.ttf") format("truetype"), url("//db.onlinewebfonts.com/t/b5eae9bab2129f4acd5fcd349dc804fe.svg#Nirmala UI Semilight") format("svg"); }
@font-face {
    font-family: CORBEL;
    src: url('{{ url('fonts/corbel/CORBEL.TTF') }}');
}
    .floating-wpp-button
    {
        width:52px !important;
        height:52px !important;
    }

    h1 { 
      font-family: Papyrus, fantasy;
      font-style: normal; 
      font-variant: normal;
      font-weight: 700;
 
     }

     h2 { 
      font-family: Papyrus, fantasy;
      font-style: normal; 
      font-variant: normal;
      font-weight: 700;
 
     }
     h3 { 
     font-family: Papyrus, fantasy !important;
     font-size: 18px; 
     font-style: normal; 
     font-variant: normal; 
     font-weight: 700; 
     line-height: 15.4px; 
    }

    h4 { 
     font-family: Papyrus, fantasy !important;
     font-size: 18px; 
     font-style: normal; 
     font-variant: normal; 
     font-weight: 700; 
     line-height: 15.4px; 
    }
     p { 
         font-family: Nirmala UI Semilight !important;
         font-size: 18px;
         font-style: normal;
         font-variant: normal;
         font-weight: 400;
         line-height: 20px;
      } 

      a { 
        font-family: Nirmala UI Semilight !important;
         font-size: 18px;
         font-style: normal;
         font-variant: normal;
         font-weight: 400;
         line-height: 20px;
      } 


      span { 
        font-family: Nirmala UI Semilight !important;
         font-size: 18px;
         font-style: normal;
         font-variant: normal;
         font-weight: 400;
         line-height: 20px;
      } 
      
     
      label{
        font-family: Nirmala UI Semilight !important;
         font-size: 18px;
         font-style: normal;
         font-variant: normal;
         font-weight: 800;
         line-height: 20px; 
      }

      li{
        font-family: Nirmala UI Semilight !important;
         font-size: 18px;
         font-style: normal;
         font-variant: normal;
         font-weight: 800;
         line-height: 20px; 
         font-family: CORBEL;
         
         
      }
   
</style>