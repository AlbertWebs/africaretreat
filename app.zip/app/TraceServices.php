<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TraceServices extends Model
{
    public $table = 'traceservices';
}
