<div class="additional_txt">
<h6>Cancellation policy</h6>
<p>If you need to cancel your Booking, we respectfully request at least 48Hours notice. 😊</p>

<p>Any cancellation or reschedule made less than 48 hours will result in a cancellation fee😐</p>

<p>In the event of a true, unavoidable emergency, all or part of your cancellation fee may be applied to future services.🤔</p>
</div>